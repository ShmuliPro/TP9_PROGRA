using Microsoft.AspNetCore.Mvc;
using TP9.Models;

namespace TP9.Controllers;

public class AccountController : Controller
{
   public IActionResult Index(){
        return View();
    }
    public IActionResult Registro(){
        return View("Registro");
    }
    public IActionResult IngresarRegistro(Usuario usuario)
    {
      BD.Poneralusuario(usuario);
      return View("Index");
    }
     public IActionResult Login(string UserName, string Contraseña)
     {
        ViewBag.Usuario = BD.Loginiarusuario(UserName, Contraseña);
       
       
        if(ViewBag.Usuario != null)
        {
         return View("Bienvenida");
        }
        
        else
        {
         ViewBag.Error = "La contra no es del usuario";
         return View("Index");}
        
     }
     public IActionResult CambioContra(string UserName, string Contraseña)
     {
        BD.CambioContra(UserName, Contraseña);
        return View("Index");
     }
      public IActionResult IrCambioContra()
      {
         return View("ContraseñaOlvidada");
      }
      public IActionResult Bienvenida()
      {
         return View();
      }
}